package com.ecommerce.qa.testcases;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ecommerce.qa.pages.JupiterToysHomePage;

public class JupiterTestCase1 {
	
	private static WebDriver driver=null;
	static JavascriptExecutor js;
	JupiterToysHomePage jupiterHome;

	@BeforeMethod
	public void setUp() throws Exception {
		String currentDirectory = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", currentDirectory+"\\chromedriver.exe");
		driver = new ChromeDriver();
		js = (JavascriptExecutor) driver;
		driver.get("https://www.amazon.in/.");
		driver.manage().window().maximize();
	}

	@Test
	public void jupiterContactTest() throws InterruptedException, IOException {
		String title = driver.getTitle();
		System.out.println("Title Of the page : " + title);
		Assert.assertEquals(title, "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in");
		JupiterToysHomePage.Hamburger(driver).click();
		Thread.sleep(2000);
		JupiterToysHomePage.TVAppliances(driver).click();
		Thread.sleep(2000);
		JupiterToysHomePage.Television(driver).click();
		Thread.sleep(1000);
		JupiterToysHomePage.Samsung(driver).click();
		Thread.sleep(1000);
		JupiterToysHomePage.FilterRow(driver).click();
		Thread.sleep(1000);
		JupiterToysHomePage.HighToLow(driver).click();
		Thread.sleep(1000);
		JupiterToysHomePage.FirstRowElement(driver).click();
		
		//Switch to Window
		String parent=driver.getWindowHandle();
		//Loop through until we find a new window handle
		for (String windowHandle : driver.getWindowHandles()) {
		    if(!parent.contentEquals(windowHandle)) {
		        driver.switchTo().window(windowHandle);
		        JupiterToysHomePage.Quantity(driver).click();
		        break;
		    }
		}
		
		//Add the Count Of the Product as 5
		WebElement dropdown =JupiterToysHomePage.Quantity(driver);
        for(int i=0;i<=4;i++) {
		dropdown.sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(1000);
        }	
        dropdown.sendKeys(Keys.ENTER);
	}
	
	@AfterMethod
	public void close() {
		driver.close();
	}
	

}
