package com.ecommerce.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JupiterToysHomePage {
	
	private static WebElement  element= null;
	
	public static WebElement Hamburger(WebDriver driver) {
		element  = driver.findElement(By.id("nav-hamburger-menu"));
		return element;
	}
	
	public static WebElement PassName(WebDriver driver) {
		element  = driver.findElement(By.id("login_form_password_input"));
		return element;
	}
	
	
	public static WebElement Login(WebDriver driver) {
		element  = driver.findElement(By.id("login_form_login_btn"));
		return element;
	}

	public static WebElement TVAppliances(WebDriver driver) {		
		element  = driver.findElement(By.xpath("//div[contains(text(),'TV, Appliances, Electronics')]"));
		return element;
	}

	public static WebElement Television(WebDriver driver) {
		element  = driver.findElement(By.xpath("//a[contains(text(),'Televisions')]"));
		return element;
	}

	public static WebElement Samsung(WebDriver driver) {
		element  = driver.findElement(By.xpath("(//span[contains(text(),'Samsung')])[2]"));
		return element;
	}

	public static WebElement FilterRow(WebDriver driver) {
		element  = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']"));
		return element;
	}
	
	public static WebElement HighToLow(WebDriver driver) {
		element = driver.findElement(By.xpath("//a[contains(text(),'Price: High to Low')]"));
		return element;
	}
	
	public static WebElement FirstRowElement(WebDriver driver) {
		element = driver.findElement(By.xpath("//div[@class='s-main-slot s-result-list s-search-results sg-row']/div[2]"));
		return element;
	}
	
	public static WebElement Assert(WebDriver driver) {
		element = driver.findElement(By.xpath("//h1[@class='a-size-base-plus a-text-bold']"));
		return element;
	}
	public static WebElement Quantity(WebDriver driver) {
		element = driver.findElement(By.id("quantity"));
		return element;
	}
	
	
}
